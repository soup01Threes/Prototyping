
from flask import Flask

app=Flask(__name__)

@app.route('/')
def hello_world():
    return "hello"

@app.route('/mydata')
def get_data():
    return "data-1-2-3-4",200


if __name__=='__main__':
    app.run(host='192.168.0.50')

