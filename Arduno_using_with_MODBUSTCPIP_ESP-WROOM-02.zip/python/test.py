from pyModbusTCP.client import ModbusClient
import time

SERVER_HOST = "192.168.137.5"
SERVER_PORT = 502
SERVER_U_ID = 2

c = ModbusClient()
c.open()
c.is_open()
time.sleep(1)
regs = c.read_input_registers(100,2)
print(regs)
c.close()